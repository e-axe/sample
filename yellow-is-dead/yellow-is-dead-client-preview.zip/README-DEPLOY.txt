舞台「イエローが死んだ」クライアント確認用LP
2026-10-09 最新公式情報・UIレビュー反映版（CAST18名・Wキャスト出演日程・販売期間/URL）
index.html、style.css、app.js、assets/、fonts/を同じ階層関係で設置してください。
静的Webサーバーで動作し、サーバー側Node.js/DBは不要です。
確認用noindex設定。販売開始の確認までは発売前案内。CAST写真は正式氏名付き仮枠です。
